# Power Automate + Copilot flow — setup guide

The Streamlit app keeps **all prompt logic in Python** (`ai_engine.py`) and treats
Power Automate as a **thin relay**: it sends fully-built prompts, the flow forwards
them to an AI action (AI Builder GPT prompt or a Copilot Studio agent) and returns
the text.

> This is the **same contract** used by the Quarkus PoC, so one flow serves both.

## 1. The contract

**App → Flow (POST body):**
```json
{
  "task": "BUILD_RCM | SUGGEST_TESTS | ANALYZE_PHASE | CONCLUDE",
  "responseFormat": "JSON_ARRAY | JSON_OBJECT | TEXT",
  "systemPrompt": "…full system prompt…",
  "userPrompt": "…full user prompt (transcripts, RCM, evidence)…"
}
```

**Flow → App (Response body):**
```json
{ "output": "…the model's text…" }
```
On failure return `{ "error": "…message…" }`.

`task` / `responseFormat` are advisory — the relay flow can ignore them.

## 2. Build the flow (relay)

1. **Instant cloud flow** → trigger **"When an HTTP request is received"**.
2. Request Body JSON Schema:
   ```json
   {
     "type": "object",
     "properties": {
       "task": { "type": "string" },
       "responseFormat": { "type": "string" },
       "systemPrompt": { "type": "string" },
       "userPrompt": { "type": "string" }
     }
   }
   ```
3. Add the AI step (pick one):
   - **AI Builder → "Create text with GPT"** — set the prompt input to
     `systemPrompt` + newline + `userPrompt` (dynamic-content tokens).
   - **Copilot Studio agent** — call a topic/action that takes the combined
     prompt and returns text.
4. Add a **Response** action: status `200`, body `{ "output": <AI text token> }`.
5. Save, open the trigger, **copy the HTTP POST URL** (ends in `…&sig=…`).

## 3. Give the URL to the app

Either:
- paste it into the sidebar (**⚙️ AI relay**) at demo time, or
- set `UC01_FLOW_URL` in `.env` / the environment.

## 4. Data residency

This replaces the original local-only LLM. `systemPrompt`/`userPrompt` carry
transcript and evidence text, so confirm the flow's AI action and tenant region
meet your data-residency requirements before sending real audit content. Keep the
flow inside the approved M365/Azure tenant and prefer a configuration that does not
retain prompts for training.
