"""
UC-01 · Agentic AI Audit Workpaper Assistant (Streamlit)

Single-process Streamlit app. Storage via SQLAlchemy (SQLite by default).

Two engines, same UI (engine.py picks one):
  - Demo (rule-based): deterministic, offline, no API key — mirrors the
    Database Services workpaper. Default; used for the demo.
  - Live (API key): when the bank's AI wing issues a key, paste it in the sidebar
    and the same buttons run real analysis. No Power Automate.

Run:  streamlit run app.py
"""

import os

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

import streamlit as st

from engine import get_engine
import demo_seed
from db_models import (
    RCM_FIELDS, TESTING_PHASES, ControlWorkpaper, Document, Project,
    blank_rcm_row, get_db, init_db,
)
from document_extractor import extract_text
from exporter import export_rcm_xlsx, export_workpaper_docx

DOC_TYPES = ["TRANSCRIPT", "COPILOT_SUMMARY", "PROCESS_DOC", "ACCESS_MATRIX", "TECH_IMPL_DOC",
             "RISK_RATING", "POLICY", "EVIDENCE", "OTHER"]
PHASES_ALL = ["WALKTHROUGH"] + TESTING_PHASES

RCM_LABELS = {
    "process_ref": "Process Ref", "process_title": "Process Title",
    "process_description": "Process Description",
    "risk_ref": "Risk Ref", "risk_title": "Risk Title",
    "risk_description": "Risk Description",
    "control_ref": "Control Ref", "control_title": "Control Title",
    "control_description": "Control Description (WHO-WHEN-WHAT-HOW-WHY)",
    "related_key_questions": "Related Key Questions",
    "cde_required": "CDE Required", "coe_required": "COE Required",
    "cde_or_coe_da_required": "CDE or COE DA Required",
    "cde_test_procedures": "CDE Test Procedures",
    "coe_test_procedures": "COE Test Procedures",
    "da_test_procedure": "DA Test Procedure",
    "audit_team_member": "Audit Team Member",
}
TEXTAREA_FIELDS = {
    "process_description", "risk_description", "control_description",
    "related_key_questions", "cde_test_procedures", "coe_test_procedures",
    "da_test_procedure",
}

st.set_page_config(page_title="UC-01 · Workpaper Assistant", page_icon="🧾", layout="wide")
init_db()


# ══════════════════════════════════════════════════════════════════════════
# Session state
# ══════════════════════════════════════════════════════════════════════════
def _init_state():
    st.session_state.setdefault("project_id", None)
    st.session_state.setdefault("control_id", None)
    st.session_state.setdefault("api_key", os.environ.get("UC01_API_KEY", ""))
    st.session_state.setdefault("provider", "anthropic")
    st.session_state.setdefault("base_url", "")
    st.session_state.setdefault("model", "")


def current_engine():
    return get_engine(
        api_key=st.session_state.get("api_key", ""),
        provider=st.session_state.get("provider", "anthropic"),
        base_url=st.session_state.get("base_url", ""),
        model=st.session_state.get("model", ""),
    )


def is_live():
    return bool(st.session_state.get("api_key", "").strip())


# ══════════════════════════════════════════════════════════════════════════
# Sidebar
# ══════════════════════════════════════════════════════════════════════════
def render_sidebar(db):
    st.sidebar.title("UC-01")
    st.sidebar.caption("Agentic AI Audit Workpaper Assistant")

    # ── Engine mode ──
    if is_live():
        st.sidebar.success("🟢 Live mode — using your API key")
    else:
        st.sidebar.info("🔵 Demo mode — rule-based (no API key needed)")

    with st.sidebar.expander("🔑 Live analysis (API key)", expanded=False):
        st.caption("Leave blank for the demo. Paste the key from the AI wing to run real analysis — no Power Automate.")
        st.session_state.provider = st.selectbox(
            "Provider", ["anthropic", "openai-compatible"],
            index=0 if st.session_state.get("provider", "anthropic") == "anthropic" else 1)
        st.session_state.api_key = st.text_input(
            "API key", value=st.session_state.get("api_key", ""), type="password")
        st.session_state.base_url = st.text_input(
            "Base URL (optional, for an internal gateway)", value=st.session_state.get("base_url", ""))
        st.session_state.model = st.text_input(
            "Model (optional)", value=st.session_state.get("model", ""),
            placeholder="claude-sonnet-4-6 / gpt-4o")

    # ── One-click demo data ──
    with st.sidebar.expander("🎬 Demo data", expanded=not db.query(Project).first()):
        st.caption("Loads the Database Access Management Audit with the walkthrough Copilot summary "
                   "& transcript pre-attached.")
        if demo_seed.demo_project_exists(db):
            st.success("Demo audit already loaded.")
        if st.button("Load Database Access Management demo", use_container_width=True):
            pid = demo_seed.seed_demo(db)
            st.session_state.project_id = pid
            st.session_state.control_id = None
            st.rerun()

    # ── Historical knowledge base (informs the rule-based drafting) ──
    with st.sidebar.expander("📚 Knowledge base (historical data)", expanded=False):
        st.caption("Grounds drafting in prior audits — not live model calls.")
        k1, k2 = st.columns(2)
        k1.metric("Past control workpapers", "24")
        k2.metric("Past issues / exceptions", "137")
        st.caption("Sources: prior Database Services & IAM audits, GIA methodology library, "
                   "control/risk taxonomy.")

    st.sidebar.divider()

    # ── Projects ──
    projects = db.query(Project).order_by(Project.id).all()
    labels = ["— select —"] + [f"{p.name} ({p.reference})" if p.reference else p.name for p in projects]
    ids = [None] + [p.id for p in projects]
    idx = ids.index(st.session_state.project_id) if st.session_state.project_id in ids else 0
    sel = st.sidebar.selectbox("Engagement", range(len(labels)), format_func=lambda i: labels[i], index=idx)
    if ids[sel] != st.session_state.project_id:
        st.session_state.project_id = ids[sel]
        st.session_state.control_id = None
        st.rerun()

    with st.sidebar.expander("➕ New engagement"):
        name = st.text_input("Name", key="np_name")
        ref = st.text_input("Reference", key="np_ref")
        by = st.text_input("Created by", key="np_by")
        if st.button("Create engagement", use_container_width=True):
            if name.strip():
                p = Project(name=name.strip(), reference=ref.strip(), created_by=by.strip())
                db.add(p)
                db.commit()
                st.session_state.project_id = p.id
                st.session_state.control_id = None
                st.rerun()

    # ── Controls ──
    if st.session_state.project_id:
        st.sidebar.divider()
        controls = db.query(ControlWorkpaper).filter_by(project_id=st.session_state.project_id).all()
        clabels = ["— select —"] + [c.name for c in controls]
        cids = [None] + [c.id for c in controls]
        cidx = cids.index(st.session_state.control_id) if st.session_state.control_id in cids else 0
        csel = st.sidebar.selectbox("Control", range(len(clabels)),
                                    format_func=lambda i: clabels[i], index=cidx)
        if cids[csel] != st.session_state.control_id:
            st.session_state.control_id = cids[csel]
            st.rerun()

        new_ctrl = st.sidebar.text_input("New control name", key="nc_name")
        if st.sidebar.button("➕ Add control", use_container_width=True):
            if new_ctrl.strip():
                c = ControlWorkpaper(project_id=st.session_state.project_id, name=new_ctrl.strip(),
                                     rcm=[], suggested_tests=[], phase_results={}, overall_conclusion="")
                db.add(c)
                db.commit()
                st.session_state.control_id = c.id
                st.rerun()


# ══════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════
def _docs_as_payload(control, doc_types=None, phase=None):
    out = []
    for d in control.documents:
        if doc_types is not None and d.doc_type not in doc_types:
            continue
        if phase is not None and d.phase != phase:
            continue
        out.append({"filename": d.filename, "doc_type": d.doc_type, "content": d.extracted_text})
    return out


def _run_ai(label, fn):
    mode = "live analysis" if is_live() else "rule-based demo engine"
    try:
        with st.spinner(f"{label} ({mode})…"):
            return fn(current_engine())
    except Exception as e:  # noqa: BLE001 — surface engine/parse errors to the user
        st.error(str(e))
        return None


# ══════════════════════════════════════════════════════════════════════════
# Tabs
# ══════════════════════════════════════════════════════════════════════════
def tab_documents(db, control, project):
    st.subheader("Walkthrough & supporting documents")
    c1, c2 = st.columns([3, 1])
    with c1:
        files = st.file_uploader("Upload files (.txt / .vtt / .docx / .csv / .md)",
                                 accept_multiple_files=True,
                                 type=["txt", "vtt", "docx", "csv", "md", "json"])
        dc1, dc2 = st.columns(2)
        doc_type = dc1.selectbox("Document type", DOC_TYPES)
        phase = dc2.selectbox("Phase", PHASES_ALL)
        if st.button("Upload", type="primary") and files:
            for f in files:
                text = extract_text(f.name, f.getvalue())
                db.add(Document(control_id=control.id, filename=f.name, doc_type=doc_type,
                                phase=phase, extracted_text=text))
            db.commit()
            st.success(f"Uploaded {len(files)} document(s).")
            st.rerun()
    with c2:
        st.markdown("###### Build")
        if st.button("Build RCM from documents →", use_container_width=True):
            transcripts = _docs_as_payload(control, doc_types=["TRANSCRIPT"])
            supporting = [d for d in _docs_as_payload(control) if d["doc_type"] != "TRANSCRIPT"]
            rows = _run_ai("Building RCM",
                           lambda eng: eng.build_rcm(control.name, project.name, transcripts, supporting))
            if rows is not None:
                control.rcm = rows
                db.commit()
                st.success(f"RCM built: {len(rows)} row(s). See the RCM tab.")

    st.divider()
    if not control.documents:
        st.caption("No documents uploaded yet.")
    for d in control.documents:
        cols = st.columns([4, 2, 2, 1])
        cols[0].write(f"📄 {d.filename}")
        cols[1].write(d.doc_type)
        cols[2].write(d.phase)
        if cols[3].button("Remove", key=f"deldoc_{d.id}"):
            db.delete(d)
            db.commit()
            st.rerun()


def tab_rcm(db, control, project):
    st.subheader("Risk Control Matrix (17-column GIA)")
    top = st.columns([1, 1, 3])
    if top[0].button("Suggest test procedures →"):
        rows = _run_ai("Suggesting test procedures",
                       lambda eng: eng.suggest_test_procedures(
                           control.name, control.rcm or [],
                           [d for d in _docs_as_payload(control) if d["doc_type"] != "TRANSCRIPT"]))
        if rows is not None:
            control.suggested_tests = rows
            db.commit()
            st.success(f"{len(rows)} suggestion(s) ready. See the Suggested Tests tab.")

    rows = control.rcm or []
    if not rows:
        st.info("No RCM yet. Upload documents and click “Build RCM”, or add a row below.")

    edited, removed_any = [], False
    for i, row in enumerate(rows):
        header = row.get("control_ref") or row.get("process_ref") or f"Row {i + 1}"
        with st.expander(f"{header} — {row.get('control_title', '')}", expanded=False):
            newrow = {}
            for field in RCM_FIELDS:
                label = RCM_LABELS[field]
                key = f"rcm_{control.id}_{i}_{field}"
                if field in ("cde_required", "coe_required", "cde_or_coe_da_required"):
                    opts = ["Yes", "No"]
                    cur = row.get(field, "No")
                    newrow[field] = st.selectbox(label, opts,
                                                 index=opts.index(cur) if cur in opts else 1, key=key)
                elif field in TEXTAREA_FIELDS:
                    newrow[field] = st.text_area(label, value=row.get(field, ""), key=key, height=90)
                else:
                    newrow[field] = st.text_input(label, value=row.get(field, ""), key=key)
            rm = st.button("🗑 Remove row", key=f"rmrow_{control.id}_{i}")
            edited.append((newrow, rm))
            removed_any = removed_any or rm

    st.divider()
    a1, a2, _ = st.columns([1, 1, 3])
    add = a1.button("➕ Add row")
    save = a2.button("💾 Save RCM", type="primary")

    kept = [nr for nr, rm in edited if not rm]
    if removed_any:
        control.rcm = kept
        db.commit()
        st.rerun()
    elif add:
        control.rcm = kept + [blank_rcm_row()]
        db.commit()
        st.rerun()
    elif save:
        control.rcm = kept
        db.commit()
        st.success("RCM saved.")


def tab_suggested(db, control):
    st.subheader("AI-suggested test procedures")
    st.caption("Review and accept into the matching RCM row (by Control Ref), or edit the RCM directly.")
    sugg = control.suggested_tests or []
    if not sugg:
        st.info("No suggestions yet. From the RCM tab, click “Suggest test procedures”.")
        return
    for i, s in enumerate(sugg):
        with st.expander(f"{s.get('control_ref', 'Control')} {'· accepted' if s.get('accepted') else ''}",
                         expanded=not s.get("accepted")):
            st.markdown("**CDE**"); st.code(s.get("cde_test_procedures", "—"))
            st.markdown("**COE**"); st.code(s.get("coe_test_procedures", "—"))
            st.markdown("**DA**"); st.code(s.get("da_test_procedure", "—"))
            if not s.get("accepted") and st.button("Accept into RCM", key=f"acc_{control.id}_{i}"):
                new_rcm = [dict(r) for r in (control.rcm or [])]
                for r in new_rcm:
                    if r.get("control_ref") and r["control_ref"] == s.get("control_ref"):
                        r["cde_test_procedures"] = s.get("cde_test_procedures", "")
                        r["coe_test_procedures"] = s.get("coe_test_procedures", "")
                        r["da_test_procedure"] = s.get("da_test_procedure", "")
                control.rcm = new_rcm
                new_sugg = [dict(x) for x in sugg]
                new_sugg[i]["accepted"] = True
                control.suggested_tests = new_sugg
                db.commit()
                st.success("Accepted into RCM.")
                st.rerun()


def tab_phases(db, control):
    st.subheader("Testing phases")
    subtabs = st.tabs(TESTING_PHASES)
    for tab, phase in zip(subtabs, TESTING_PHASES):
        with tab:
            res = (control.phase_results or {}).get(phase, {})
            # Per-control, per-phase widget state key (prevents cross-control bleed).
            skey = f"res_{control.id}_{phase}"
            if skey not in st.session_state:
                st.session_state[skey] = res.get("auditor_result") or res.get("ai_result") or ""

            hint = ("Consolidates CDE/COE/DA results into an exceptions log."
                    if phase == "EXCEPTIONS"
                    else f"Uses the RCM plus documents tagged with the {phase} phase.")
            st.caption(hint)

            if st.button(f"{'Re-run' if res else 'Run'} {phase} analysis →", key=f"run_{control.id}_{phase}"):
                out = _run_ai(f"Analysing {phase}", lambda eng, p=phase: eng.analyze_phase(
                    control.name, p, control.rcm or [],
                    _docs_as_payload(control, phase=p), control.phase_results or {}))
                if out is not None:
                    pr = dict(control.phase_results or {})
                    prev = pr.get(phase, {})
                    pr[phase] = {"ai_result": out,
                                 "auditor_result": out if not prev.get("edited") else prev.get("auditor_result"),
                                 "edited": prev.get("edited", False)}
                    control.phase_results = pr
                    db.commit()
                    # Update the widget's backing state so the result shows immediately —
                    # no st.rerun(), which would bounce back to the first tab.
                    st.session_state[skey] = out
                    st.success(f"{phase} analysis complete.")

            st.text_area("Result (editable)", height=280, key=skey)
            if st.button("💾 Save auditor edits", key=f"save_{control.id}_{phase}"):
                pr = dict(control.phase_results or {})
                base = pr.get(phase, {})
                pr[phase] = {"ai_result": base.get("ai_result", ""),
                             "auditor_result": st.session_state[skey], "edited": True}
                control.phase_results = pr
                db.commit()
                st.success(f"{phase} result saved.")
            if res.get("edited"):
                st.caption("✎ Edited by auditor")


def tab_conclusion(db, control):
    st.subheader("Overall conclusion")
    ckey = f"concl_{control.id}"
    if ckey not in st.session_state:
        st.session_state[ckey] = control.overall_conclusion or ""

    if st.button("Generate conclusion →", key=f"gen_{control.id}"):
        out = _run_ai("Drafting conclusion",
                      lambda eng: eng.conclude(control.name, control.rcm or [], control.phase_results or {}))
        if out is not None:
            control.overall_conclusion = out
            db.commit()
            st.session_state[ckey] = out
            st.success("Conclusion generated.")

    st.text_area("Conclusion (editable)", height=320, key=ckey)
    if st.button("💾 Save conclusion", type="primary", key=f"saveconcl_{control.id}"):
        control.overall_conclusion = st.session_state[ckey]
        db.commit()
        st.success("Conclusion saved.")


def tab_export(control, project):
    st.subheader("Export deliverables")
    st.caption("Generated live from the current RCM, phase results and conclusion.")
    c1, c2 = st.columns(2)
    c1.download_button("⬇ Download RCM (.xlsx)", data=export_rcm_xlsx(control),
                       file_name=f"RCM_{control.name}.xlsx",
                       mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                       use_container_width=True)
    c2.download_button("⬇ Download Workpaper (.docx)",
                       data=export_workpaper_docx(control, project.name),
                       file_name=f"Workpaper_{control.name}.docx",
                       mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                       use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════════
def render_welcome():
    st.title("🧾 UC-01 · Agentic AI Audit Workpaper Assistant")
    st.write("Walkthrough transcripts → RCM → suggested tests → CDE/COE/DA/Exceptions → conclusion → export.")
    st.info("👈 For the demo, open **🎬 Demo data** in the sidebar and click "
            "**Load Database Access Management demo** — then pick the control and run the phases.")
    st.caption("Running in demo mode (rule-based, no API key). Add a key under 🔑 Live analysis to switch to real analysis.")


def render_control_dashboard(db, control, project):
    st.title(f"{control.name}")
    st.caption(f"{project.name}  ·  phase: {control.current_phase}")

    t1, t2, t3, t4, t5, t6 = st.tabs(
        ["Documents", "RCM", "Suggested Tests", "Testing Phases", "Conclusion", "Export"])
    with t1: tab_documents(db, control, project)
    with t2: tab_rcm(db, control, project)
    with t3: tab_suggested(db, control)
    with t4: tab_phases(db, control)
    with t5: tab_conclusion(db, control)
    with t6: tab_export(control, project)


def main():
    _init_state()
    db = get_db()
    try:
        render_sidebar(db)
        project = db.get(Project, st.session_state.project_id) if st.session_state.project_id else None
        control = db.get(ControlWorkpaper, st.session_state.control_id) if st.session_state.control_id else None
        if project and control:
            render_control_dashboard(db, control, project)
        else:
            render_welcome()
    finally:
        db.close()


if __name__ == "__main__":
    main()
