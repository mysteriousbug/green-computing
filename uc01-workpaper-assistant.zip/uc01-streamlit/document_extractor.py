"""
UC-01 · Document text extraction

Extracts plain text from uploaded audit inputs so only text is persisted and sent
to the AI relay. Handles MS Teams transcripts (.txt, .vtt), .docx process/policy
docs, and .csv/.md/.json. Extend with pdfplumber/PyPDF for .pdf.
"""

import io

from docx import Document as DocxDocument


def extract_text(filename: str, data: bytes) -> str:
    lower = (filename or "").lower()
    if lower.endswith(".docx"):
        return _extract_docx(data)
    text = data.decode("utf-8", errors="replace")
    if lower.endswith(".vtt"):
        return _clean_vtt(text)
    return text


def _extract_docx(data: bytes) -> str:
    doc = DocxDocument(io.BytesIO(data))
    lines = [p.text for p in doc.paragraphs]
    # include table cell text too
    for table in doc.tables:
        for row in table.rows:
            lines.append(" | ".join(c.text for c in row.cells))
    return "\n".join(lines)


def _clean_vtt(vtt: str) -> str:
    """Strip WEBVTT headers, cue numbers and timestamps; keep spoken lines."""
    out = []
    for line in vtt.splitlines():
        t = line.strip()
        if not t or t.upper() == "WEBVTT":
            continue
        if t.isdigit():
            continue
        if "-->" in t:
            continue
        if t.startswith(("NOTE", "STYLE")):
            continue
        out.append(t)
    return "\n".join(out)
