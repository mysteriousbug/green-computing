"""
UC-01 · Demo fixtures — Database Services Audit workpaper

Curated, workpaper-accurate content for the deterministic (rule-based) demo engine.
Three control workpapers, each with its 17-column RCM row(s) and per-phase findings
mirroring the real Database Services audit:

  CONFIG_PATCH  Database Configuration and Patch Management (CO1.0)
  PRIV_ACCESS   Database Privileged Access Management (CO2.0)
  BACKUP        Database Backup and Restoration (CO3.0)

Everything here is deterministic — the engine returns exactly this, so the demo is
identical every run. When a real API key is supplied the app uses the live LLM
path instead (see llm_engine.py); this fixture is untouched.
"""

# ── RCM rows (dict keys match db_models.RCM_FIELDS) ───────────────────────────

_CONFIG_PATCH_RCM = [
    {
        "process_ref": "1",
        "process_title": "Database Configuration",
        "process_description": (
            "Database configuration is the process of setting up and tuning a Database "
            "Management System (DBMS) for performance, security and reliability, involving "
            "defining schemas, memory, user access, backups and performance parameters."
        ),
        "risk_ref": "R1",
        "risk_title": "Inappropriate database configuration",
        "risk_description": (
            "Inappropriate database configuration significantly increases the risk of data "
            "breaches, financial and reputational damage, legal penalties and operational "
            "disruptions. Misconfigurations create security vulnerabilities that attackers "
            "can easily exploit."
        ),
        "control_ref": "CO1.0",
        "control_title": "Database Configuration and Patch Management",
        "control_description": (
            "The Database team (WHO) on request from business (WHEN) builds and configures a "
            "new database (WHAT) per the latest configuration baseline through semi-automated "
            "tools (HOW/WHERE) to ensure databases are secure and operationally aligned to "
            "business requirements (WHY).\n\n"
            "Control attributes:\n"
            "a) Security requirements align with Group and Industry requirements.\n"
            "b) Configuration baselines (TIP) exist per database class and are reviewed to a "
            "defined frequency.\n"
            "c) Deployment is gated by Security Acceptance Test (SAT) and Operation Acceptance "
            "Test (OAT).\n"
            "d) Security patches are assessed and deployed within defined SLAs."
        ),
        "related_key_questions": (
            "Q1. Are database configuration documents (TIP) up to date with industry practices "
            "and aligned to Group Standards for the database types used in the Group?\n"
            "Q2. Is compliance with the configuration baseline monitored, and are deviations "
            "remediated or risk-accepted within SLA?\n"
            "Q3. Are security patches assessed and deployed within defined SLAs, with breaches "
            "tracked and escalated?"
        ),
        "cde_required": "Yes",
        "coe_required": "Yes",
        "cde_or_coe_da_required": "Yes",
        "cde_test_procedures": (
            "Process Walkthrough\n"
            "1. Perform a walkthrough with the Database team to understand the process of "
            "building, configuring and deploying a database and validate if:\n"
            "a) Configuration baseline documents (security and non-security) exist for the "
            "different database classes used in the Group and are reviewed regularly.\n"
            "b) A control exists to ensure a database is deployed only post control-validation "
            "checks such as Security Acceptance Test (SAT) and Operation Acceptance Test (OAT).\n"
            "c) A control exists to identify, remediate or risk-manage configuration "
            "non-compliance prior to deployment.\n\n"
            "Test Of One\n"
            "2. Obtain the latest Technical Implementation Procedure (TIP) document for one "
            "database class used in the Group, and validate if:\n"
            "a) Documents are reviewed and approved per the defined frequency."
        ),
        "coe_test_procedures": (
            "Based on GIA sampling methodology:\n"
            "1. For the remaining database classes used in the Group, validate if the TIP:\n"
            "a) Documents are reviewed and approved per the defined frequency.\n"
            "2. For a sample of quarterly configuration compliance scans, validate that "
            "deviations are remediated within SLA or formally risk-accepted.\n"
            "3. For a sample of security patches (incl. Oracle CPUs), validate assessment and "
            "deployment within SLA, and that breaches are tracked and escalated."
        ),
        "da_test_procedure": (
            "Analyse the full population of configuration-scan deviations and patch records for "
            "the review period:\n"
            "1. Trend deviation volumes and ageing across quarters (Q3/Q4 2025).\n"
            "2. Identify patches deployed outside SLA and quantify the ageing.\n"
            "3. Reconcile risk-accepted items to valid, in-date risk acceptances."
        ),
        "audit_team_member": "Ananya Aithal",
    }
]

_PRIV_ACCESS_RCM = [
    {
        "process_ref": "2",
        "process_title": "Database Privileged Access Management",
        "process_description": (
            "Provisioning, modification, revocation and monitoring of privileged access to "
            "production databases, managed through a Privileged Access Management (PAM) "
            "solution (CyberArk)."
        ),
        "risk_ref": "R2",
        "risk_title": "Unauthorised or excessive privileged access",
        "risk_description": (
            "Unauthorised, excessive or unmonitored privileged database access can lead to "
            "data exfiltration, unauthorised changes, fraud and regulatory breach. Weak "
            "segregation of duties or delayed revocation increases the window of exposure."
        ),
        "control_ref": "CO2.0",
        "control_title": "Database Privileged Access Management",
        "control_description": (
            "The DBA and IAM teams (WHO), on an approved access request (WHEN), provision "
            "privileged database access through the CyberArk PAM platform (WHAT) following a "
            "multi-step approval workflow and vaulting of credentials (HOW/WHERE) to ensure "
            "only authorised users hold privileged access and all sessions are monitored (WHY).\n\n"
            "Control attributes:\n"
            "a) Multi-step approval (line manager, DBA team lead, control owner) prior to grant.\n"
            "b) Privileged credentials vaulted and session activity recorded.\n"
            "c) Timely revocation on leaver/contract-end events.\n"
            "d) Periodic reconciliation of vaulted accounts to authorised users."
        ),
        "related_key_questions": (
            "Q1. Are all privileged access grants supported by the full approval chain and "
            "provisioned within SLA?\n"
            "Q2. Does the approval workflow enforce segregation of duties for same-team requests?\n"
            "Q3. Is privileged access revoked within SLA on leaver/contract-end, and are all "
            "privileged accounts vaulted and monitored?"
        ),
        "cde_required": "Yes",
        "coe_required": "Yes",
        "cde_or_coe_da_required": "Yes",
        "cde_test_procedures": (
            "Process Walkthrough\n"
            "1. Walk through the privileged-access lifecycle (request, approve, provision, "
            "monitor, revoke) and validate if:\n"
            "a) The approval workflow is enforced in the tooling (ServiceNow + CyberArk).\n"
            "b) Sessions are recorded and monitored.\n"
            "c) Reconciliation of vaulted accounts to authorised users is performed.\n\n"
            "Test Of One\n"
            "2. For one new privileged-access grant, validate the full approval chain, SLA "
            "adherence and vault entry."
        ),
        "coe_test_procedures": (
            "Based on GIA sampling methodology:\n"
            "1. Select a stratified sample of privileged-access events (grants, modifications, "
            "revocations, break-glass) across the review period.\n"
            "2. For each, validate approval completeness, SLA adherence, segregation of duties "
            "and vaulting/monitoring evidence."
        ),
        "da_test_procedure": (
            "1. Reconcile the full population of privileged accounts to CyberArk vault coverage.\n"
            "2. Analyse session logs for after-hours activity and potential credential sharing "
            "(shared source IPs / concurrent sessions)."
        ),
        "audit_team_member": "Ananya Aithal",
    }
]

_BACKUP_RCM = [
    {
        "process_ref": "3",
        "process_title": "Database Backup and Restoration",
        "process_description": (
            "Backup and recoverability of production databases across platforms (Oracle, MSSQL, "
            "PostgreSQL, MongoDB) using a 3-2-1 strategy with tiered RPO/RTO targets and "
            "periodic restoration testing."
        ),
        "risk_ref": "R3",
        "risk_title": "Inability to recover data within business tolerances",
        "risk_description": (
            "Failure to back up databases reliably, or inability to restore within business "
            "recovery objectives, can cause permanent data loss, prolonged outages, regulatory "
            "breach and material financial and reputational damage."
        ),
        "control_ref": "CO3.0",
        "control_title": "Database Backup and Restoration",
        "control_description": (
            "The DBA team (WHO), on a scheduled basis (WHEN), performs automated backups of "
            "production databases via Commvault and AWS Backup (WHAT) following a 3-2-1 strategy "
            "with tiered RPO/RTO and monthly restoration testing (HOW/WHERE) to ensure data is "
            "recoverable within business tolerances (WHY).\n\n"
            "Control attributes:\n"
            "a) 3-2-1 backup strategy with tiered RPO/RTO by database tier.\n"
            "b) Automated backups with daily success monitoring.\n"
            "c) Monthly restoration testing on a rotating sample.\n"
            "d) Backup integrity validation."
        ),
        "related_key_questions": (
            "Q1. Are backups performed and monitored to the defined schedule and success SLA?\n"
            "Q2. Is restoration testing performed at a frequency commensurate with database "
            "criticality (esp. Tier 1)?\n"
            "Q3. Is backup integrity validated across all database platforms?"
        ),
        "cde_required": "Yes",
        "coe_required": "Yes",
        "cde_or_coe_da_required": "No",
        "cde_test_procedures": (
            "Process Walkthrough\n"
            "1. Walk through the backup and restoration process and validate if:\n"
            "a) A 3-2-1 strategy with tiered RPO/RTO is defined and implemented.\n"
            "b) Backup success is monitored daily with timely failure remediation.\n"
            "c) Restoration testing is scheduled and evidenced.\n\n"
            "Test Of One\n"
            "2. For one database, obtain backup completion records and the most recent "
            "restoration-test result and validate against the defined RPO/RTO."
        ),
        "coe_test_procedures": (
            "Based on GIA sampling methodology:\n"
            "1. Select a stratified sample of databases across Tiers 1-3.\n"
            "2. For each, validate backup completion/success over the period and whether a "
            "restoration test was performed within the expected cycle."
        ),
        "da_test_procedure": "",
        "audit_team_member": "Ananya Aithal",
    }
]

# ── Per-phase findings (markdown) ─────────────────────────────────────────────

_CONFIG_PATCH_PHASES = {
    "CDE": (
        "## CDE — Control Design Effectiveness\n\n"
        "**Design strengths**\n"
        "- Configuration baselines (Technical Implementation Procedures, TIP) exist per "
        "database class and are the reference for build and deployment.\n"
        "- Deployment is gated by Security Acceptance Test (SAT) and Operation Acceptance Test "
        "(OAT).\n"
        "- Compliance is monitored via a quarterly Qualys configuration-compliance scan against "
        "the TIP baseline, with a 30-day remediation SLA.\n"
        "- Security patches are risk-assessed within 48 hours of release; critical patches "
        "target 30-day production deployment, tested in UAT first.\n\n"
        "**Design gaps**\n"
        "- **Scan coverage**: quarterly compliance scans cover Production and DR only; UAT and "
        "Development environments are out of scope.\n"
        "- **TIP currency**: the MSSQL TIP is overdue for review (remediation scheduled Mar 2026, "
        "contractor engaged for CIS Benchmark MSSQL 2019 mapping).\n\n"
        "**CDE conclusion: Well Designed with minor gaps.** The build/configure/patch design is "
        "sound; the coverage and TIP-currency gaps are improvement areas rather than fundamental "
        "design weaknesses."
    ),
    "COE": (
        "## COE — Control Operating Effectiveness\n\n"
        "**Configuration compliance (GIA sampling)**\n"
        "- Q3 2025: 147 deviations across production databases — 120 remediated within the 30-day "
        "SLA, 27 formally risk-accepted.\n"
        "- Q4 2025: 163 deviations (slight increase); remediation/risk-acceptance evidence "
        "obtained.\n"
        "- Risk acceptances follow governance (Technology Risk team; CISO for Critical, "
        "Infrastructure Security Manager for High; 90-day maximum validity).\n\n"
        "**Patch management (GIA sampling)**\n"
        "- Oracle Critical Patch Updates breached the 30-day production SLA: the **October 2025 "
        "CPU deployed at 47 days**; the **January 2026 CPU remained undeployed at 35 days** at the "
        "time of testing, driven by legacy-application compatibility.\n"
        "- Breaches are tracked in the ServiceNow patch dashboard and reported weekly to the "
        "Infrastructure Security Manager, but escalation has not consistently accelerated "
        "remediation (blockers are application-side).\n\n"
        "**COE conclusion: Operating with exceptions.** Configuration monitoring and remediation "
        "operate largely as designed; patch-deployment timeliness for Oracle CPUs and "
        "non-production scan coverage are operating exceptions (see Exceptions)."
    ),
    "DA": (
        "## DA — Data Analytics\n\n"
        "**Configuration deviation trend**\n"
        "- Deviation volume rose Q3→Q4 2025 (147 → 163, +10.9%). Recurring deviation categories "
        "concentrate in a small number of legacy database instances.\n"
        "- 27 of 147 Q3 deviations were risk-accepted; all reconciled to in-date risk "
        "acceptances.\n\n"
        "**Patch ageing**\n"
        "- Oracle CPU ageing exceeded the 30-day SLA on the two most recent cycles (47 days; 35 "
        "days and open). Ageing is concentrated on databases supporting legacy applications with "
        "known compatibility blockers.\n\n"
        "**DA conclusion:** Analytics corroborate the COE exceptions — an upward deviation trend "
        "and SLA-exceeding patch ageing localised to legacy estate — and support targeted "
        "remediation."
    ),
    "EXCEPTIONS": (
        "## Exceptions Log\n\n"
        "| Ref | Control | Description | Root cause | Rating | Recommended action |\n"
        "|-----|---------|-------------|-----------|--------|--------------------|\n"
        "| EX-01 | CO1.0 | Oracle Critical Patch Updates deployed outside the 30-day production "
        "SLA (Oct 2025 CPU: 47 days; Jan 2026 CPU: 35 days, open). | Legacy-application "
        "compatibility blockers; escalation not resolving root cause. | **Medium–High** | "
        "Establish a remediation plan with application owners for legacy compatibility; enforce "
        "risk-acceptance where SLA cannot be met. |\n"
        "| EX-02 | CO1.0 | Quarterly configuration-compliance scans exclude UAT and Development "
        "environments. | Scan scope limited to Production and DR. | **Medium** | Extend scan "
        "coverage to non-production, or formally risk-accept with compensating controls. |\n"
        "| EX-03 | CO1.0 | MSSQL Technical Implementation Procedure (TIP) overdue for review. | "
        "Limited internal MSSQL security expertise. | **Low–Medium** | Complete the scheduled "
        "Mar 2026 review and CIS Benchmark MSSQL 2019 mapping. |"
    ),
}

_PRIV_ACCESS_PHASES = {
    "CDE": (
        "## CDE — Control Design Effectiveness\n\n"
        "**Walkthrough:** 4 March 2026 (MS Teams; transcript + Copilot recap on file). "
        "**Attendees:** Ananya Aithal (Auditor), Edwin Joyson (Audit Lead), Raj Kumar (Auditor), "
        "Haidi Chen (DA), Rajesh Menon (DBA Team Lead), Priya Sharma (Database Security), "
        "Suresh Nair (IAM/PAM Lead). Estate in scope: 342 production instances (Oracle, MSSQL, DB2, "
        "PostgreSQL, MongoDB, AWS Aurora/RDS, Azure SQL).\n\n"
        "**Design strengths**\n"
        "- Privileged access is managed through CyberArk PAM with credential vaulting and "
        "session recording; multi-step approval (line manager, DBA team lead, control owner) "
        "enforced via ServiceNow.\n"
        "- Database Activity Monitoring via Imperva SecureSphere (light agents → DAM gateways, "
        "Data Risk Analytics baselining); native database audit logs retained for forensics.\n"
        "- Periodic reconciliation of vaulted accounts to authorised users is performed.\n\n"
        "**Design gaps**\n"
        "- MongoDB privileged accounts are provisioned outside the standard flow and not covered by "
        "CyberArk discovery.\n"
        "- No same-team segregation-of-duties check in the approval workflow.\n"
        "- No consistent periodic recertification for DBA personal accounts (application accounts "
        "recertified quarterly).\n"
        "- Revocation is manual (no automated HR trigger); break-glass lacks a defined post-use review.\n\n"
        "**Test of One (SR-2026-01187):** full approval chain present, credential vaulted, session "
        "recording enabled — no design exception on the sampled item.\n\n"
        "**CDE conclusion: Well Designed with gaps.** Core design (CyberArk, workflow, Imperva DAM, "
        "reconciliation) is sound; MongoDB discovery, same-team SoD and DBA recertification are the "
        "design gaps to remediate."
    ),
    "COE": (
        "## COE — Control Operating Effectiveness\n\n"
        "Sample of 25 privileged-access events (Oct 2025–Mar 2026): 10 new grants, 8 "
        "modifications, 5 revocations, 2 break-glass.\n\n"
        "- **New grants (10/10 compliant):** full four-step approval chain in ServiceNow, "
        "provisioned within the 3-business-day SLA, CyberArk vault entries created.\n"
        "- **Modifications (7/8 compliant):** 1 deviation — SR-2025-45892 (db_owner on an MSSQL "
        "production DB) where the DBA team lead self-approved a same-team request. Extending the "
        "review across grants/modifications found the pattern in **3 of 18 (16.7%)** — a "
        "segregation-of-duties gap in the approval workflow for same-team requests. No actual "
        "misuse was evidenced in session recordings.\n"
        "- **Revocations (4/5 within SLA):** 1 contractor revocation processed at **12 days** "
        "versus the 5-business-day SLA (CyberArk account disabled day 12).\n"
        "- **Recertification (0/5 sampled DBA accounts):** no periodic recertification evidence for "
        "the sampled DBA personal accounts in the review period.\n"
        "- **DAM alerting (14/14):** all detection rules active and generating alerts.\n\n"
        "**COE conclusion: Operating with exceptions** — same-team SoD, one late revocation, and "
        "absent DBA recertification (see Exceptions)."
    ),
    "DA": (
        "## DA — Data Analytics\n\n"
        "- **Vaulting completeness:** population of **1,247** privileged database accounts across 340+ "
        "instances (EID Report reconciled to CyberArk inventory, 28 Feb 2026 snapshot). **1,198 vaulted; "
        "49 unvaulted (3.9%)** — within the 5% appetite but above the 2.4% management reported. Breakdown "
        "of the 49: 31 application service accounts, 12 legacy PostgreSQL DBA accounts (recent PAM "
        "migration), 6 MongoDB accounts. Excluding MongoDB the unvaulted rate is 2.1%; the **MongoDB gap "
        "is a new finding** (CyberArk discovery does not scan MongoDB).\n"
        "- **DAM detection rules:** all 14 SOC detection rules validated active and generating alerts.\n"
        "- **Session analysis (12,847 sessions):** 1 unjustified after-hours session; 7 potential "
        "credential-sharing instances (concurrent/shared-source sessions).\n\n"
        "**DA conclusion:** Supports control effectiveness with exceptions — overall vaulting is strong, "
        "but the MongoDB discovery gap and session anomalies warrant remediation and investigation."
    ),
    "EXCEPTIONS": (
        "## Exceptions Log\n\n"
        "| Ref | Control | Description | Root cause | Rating | Recommended action |\n"
        "|-----|---------|-------------|-----------|--------|--------------------|\n"
        "| EX-04 | CO2.0 | Segregation-of-duties gap: DBA team lead can self-approve same-team "
        "privileged requests (3/18, 16.7%). | Approval workflow lacks a same-team SoD check. | "
        "**Medium** | Add an independent approver / SoD rule for same-team requests. |\n"
        "| EX-05 | CO2.0 | Contractor privileged access revoked 12 days after contract end vs "
        "5-day SLA. | Manual revocation without HR-trigger integration. | **Low–Medium** | "
        "Integrate leaver/contract-end feeds to auto-trigger revocation. |\n"
        "| EX-06 | CO2.0 | MongoDB privileged accounts not fully vaulted (96.1% overall). | "
        "Platform onboarding gap. | **Medium** | Onboard MongoDB privileged accounts to CyberArk. |\n"
        "| EX-07 | CO2.0 | 7 potential credential-sharing instances across 12,847 sessions. | "
        "Shared use of privileged credentials. | **Medium** | Investigate; enforce individual "
        "accountability and session controls. |\n"
        "| EX-08 | CO2.0 | No periodic access recertification for DBA personal accounts. | "
        "Recertification standard not defined for DBA accounts. | **High** | Implement semi-annual "
        "recertification of DBA accounts by the control owner. |"
    ),
}

_BACKUP_PHASES = {
    "CDE": (
        "## CDE — Control Design Effectiveness\n\n"
        "**Design strengths**\n"
        "- 3-2-1 backup strategy (industry best practice) with tiered RPO/RTO aligned to "
        "business impact.\n"
        "- Automated backups via Commvault and AWS Backup with daily success monitoring; "
        "15-minute transaction-log backups for Tier 1 provide a tight RPO.\n"
        "- Monthly restoration testing on a rotating sample of 10 databases.\n\n"
        "**Design gaps**\n"
        "- **Restoration-test frequency:** sampling 10 of 340 databases monthly implies a ~34-month "
        "cycle; a Tier 1 database could go nearly 3 years without a restoration test.\n"
        "- **Backup integrity:** no automated cross-platform integrity check; archive-log "
        "validation exists for Oracle only (no equivalent for MSSQL, PostgreSQL, MongoDB).\n\n"
        "**Compensating controls:** quarterly DR failover test (15 databases), Commvault daily "
        "success monitoring, AWS cross-region replication.\n\n"
        "**CDE conclusion: Well Designed with minor gaps.** Backup infrastructure and processes "
        "are sound; Tier 1 restoration-test frequency and cross-platform integrity validation are "
        "improvement areas."
    ),
    "COE": (
        "## COE — Control Operating Effectiveness\n\n"
        "Sample of 25 databases (Nov 2025–Feb 2026): 10 Tier 1, 10 Tier 2, 5 Tier 3.\n\n"
        "- **Backup success (24/25):** 100% backup success over the period for 24 databases. "
        "Exception: DB-ORAPROD-17 (Oracle, Tier 2) had 3 backup failures in Dec 2025, all re-run "
        "within the 4-hour SLA; root cause a temporary storage-capacity issue "
        "(ServiceNow INC-2025-78234), remediated by expanding backup storage. The monitoring "
        "control operated as designed.\n"
        "- **Restoration testing (18/25 tested):** 7 sampled databases had not been restoration-"
        "tested in the period, including **2 Tier 1** databases (DB-MSSQLPROD-03, DB-PGPROD-12).\n\n"
        "**COE conclusion: Operating with a minor exception** — Tier 1 restoration-test coverage "
        "gap (see Exceptions). Backup execution and failure remediation operate effectively."
    ),
    "DA": "",
    "EXCEPTIONS": (
        "## Exceptions Log\n\n"
        "| Ref | Control | Description | Root cause | Rating | Recommended action |\n"
        "|-----|---------|-------------|-----------|--------|--------------------|\n"
        "| EX-08 | CO3.0 | 2 Tier 1 databases (DB-MSSQLPROD-03, DB-PGPROD-12) not restoration-"
        "tested in the review period. | Monthly rotating sample too infrequent for Tier 1. | "
        "**Medium** | Mandate quarterly restoration testing for all Tier 1 databases. |\n"
        "| EX-09 | CO3.0 | No automated backup-integrity check for MSSQL / PostgreSQL / MongoDB. | "
        "Integrity validation implemented for Oracle only. | **Low–Medium** | Extend automated "
        "integrity validation across all platforms. |"
    ),
}

_CONFIG_PATCH_CONCLUSION = (
    "## Overall Conclusion — Database Configuration and Patch Management (CO1.0)\n\n"
    "**Rating: Partially Effective.**\n\n"
    "The control is **well designed**: configuration baselines (TIP), SAT/OAT deployment gating "
    "and quarterly compliance scanning provide a sound framework, and patch assessment timelines "
    "are defined and governed.\n\n"
    "**Operating exceptions** reduce effectiveness: Oracle Critical Patch Updates breached the "
    "30-day production SLA on the two most recent cycles (47 days; 35 days and open), quarterly "
    "compliance scans exclude UAT/Development, and the MSSQL TIP is overdue for review. Data "
    "analytics confirm an upward deviation trend and SLA-exceeding patch ageing concentrated in "
    "the legacy estate.\n\n"
    "**Residual risk: Medium.** Recommended actions: a legacy-compatibility remediation plan for "
    "patch timeliness (with disciplined risk-acceptance where SLA cannot be met), extension of "
    "scan coverage to non-production, and completion of the MSSQL TIP review."
)

_PRIV_ACCESS_CONCLUSION = (
    "## Overall Conclusion — Database Privileged Access Management (CO2.0)\n\n"
    "**Rating: Partially Effective.**\n\n"
    "The control is **well designed** around CyberArk PAM (enforced approval workflow, credential "
    "vaulting, session recording), Imperva DAM monitoring and periodic reconciliation.\n\n"
    "**Operating and analytics exceptions**: a segregation-of-duties gap allows same-team "
    "self-approval (3/18, 16.7%); one contractor revocation was processed at 12 days vs a 5-day SLA; "
    "MongoDB privileged accounts sit outside CyberArk discovery (49 of 1,247 unvaulted, 3.9%); and "
    "there is no periodic recertification of DBA personal accounts. Two of these (excessive/unvaulted "
    "privileged access and absent recertification) are High-rated.\n\n"
    "**Residual risk: Medium–High.** Recommended actions: implement DBA recertification, enforce "
    "same-team SoD, onboard MongoDB to CyberArk, and integrate HR leaver feeds for timely revocation."
)

_BACKUP_CONCLUSION = (
    "## Overall Conclusion — Database Backup and Restoration (CO3.0)\n\n"
    "**Rating: Effective with minor exceptions.**\n\n"
    "The control is **well designed** (3-2-1 strategy, tiered RPO/RTO, automated backups with "
    "daily monitoring) and **operates effectively** — 24 of 25 sampled databases showed 100% "
    "backup success, and the one failure was detected and remediated within SLA.\n\n"
    "**Exceptions**: 2 Tier 1 databases were not restoration-tested in the period (sampling "
    "frequency too low for Tier 1), and automated backup-integrity validation is Oracle-only.\n\n"
    "**Residual risk: Low–Medium.** Recommended actions: mandate quarterly Tier 1 restoration "
    "testing and extend integrity validation across all database platforms."
)

# ── Registry keyed by control ─────────────────────────────────────────────────

CONTROLS = {
    "CONFIG_PATCH": {
        "control_name": "Database Configuration and Patch Management",
        "rcm": _CONFIG_PATCH_RCM,
        "phases": _CONFIG_PATCH_PHASES,
        "conclusion": _CONFIG_PATCH_CONCLUSION,
    },
    "PRIV_ACCESS": {
        "control_name": "Database Privileged Access Management",
        "rcm": _PRIV_ACCESS_RCM,
        "phases": _PRIV_ACCESS_PHASES,
        "conclusion": _PRIV_ACCESS_CONCLUSION,
    },
    "BACKUP": {
        "control_name": "Database Backup and Restoration",
        "rcm": _BACKUP_RCM,
        "phases": _BACKUP_PHASES,
        "conclusion": _BACKUP_CONCLUSION,
    },
}


def match_control_key(control_name: str, docs_text: str = "") -> str | None:
    """Deterministically map a control (by name, then document keywords) to a fixture."""
    blob = f"{control_name or ''} {docs_text or ''}".lower()
    if any(k in blob for k in ["patch", "configuration", "config", "qualys", "tip", "cpu", "baseline"]):
        return "CONFIG_PATCH"
    if any(k in blob for k in ["privileged", "cyberark", "pam", "vault", "access management"]):
        return "PRIV_ACCESS"
    if any(k in blob for k in ["backup", "restoration", "restore", "commvault", "recovery"]):
        return "BACKUP"
    return None
