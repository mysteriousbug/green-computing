# UC-01 — Agentic AI Audit Workpaper Assistant (Streamlit)

Streamlit app that turns walkthrough transcripts + supporting docs into a full GIA
workpaper: 17-column RCM → suggested tests → CDE/COE/DA/Exceptions → conclusion →
`.xlsx`/`.docx` export. Every step is auditor-reviewed and editable.

## Two engines, one UI

| Mode | When | How |
|------|------|-----|
| **Demo (rule-based)** | Default. For the demo. | Deterministic, offline, no API key, no Power Automate. Mirrors the Database Services workpaper. |
| **Live (API key)** | When the AI wing issues a key | Paste the key in the sidebar → the same buttons run real analysis (Anthropic or any OpenAI-compatible endpoint). No Power Automate. |

The app auto-selects: no key → demo engine; key present → live engine.

## Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

Then in the sidebar open **🎬 Demo data → Load Database Services demo** and follow
`DEMO_RUNBOOK.md`.

Storage is a local `uc01.db` SQLite file (zero setup). Delete it to reset.

## Going live later

Sidebar **🔑 Live analysis**: choose provider (`anthropic` / `openai-compatible`),
paste the API key, optionally set a base URL (for an internal gateway) and model.
That's the whole switch — no Power Automate, no DLP dependency.

## Files

```
uc01-streamlit/
├── app.py                 Streamlit UI (sidebar + tabbed workspace)
├── engine.py              Picks demo vs live engine
├── rule_engine.py         Deterministic demo engine (curated output)
├── fixtures.py            Curated Database Services workpaper content
├── llm_engine.py          Live LLM path (Anthropic / OpenAI-compatible)
├── ai_engine.py           Prompt templates + JSON parsing (reused by llm_engine)
├── demo_seed.py           One-click seed of the demo audit
├── db_models.py           SQLAlchemy models
├── document_extractor.py  txt / vtt / docx extraction
├── exporter.py            RCM .xlsx + workpaper .docx
├── DEMO_RUNBOOK.md         Click-by-click demo script
└── test_data/             Transcripts + evidence for the 3 controls
```

## Notes
- Demo output is deterministic and identical every run — safe for a live demo.
- Prompts preserved for live mode: WHO-WHEN-WHAT-HOW-WHY controls; CDE = Walkthrough
  + Test of One; COE = GIA sampling.
- `power-automate/` and the relay remain in the tree for reference but are not used
  by the app any more.
