"""
UC-01 · Demo seeder

One click creates the Database Access Management Audit project and its star control
workpaper, pre-loading the walkthrough Copilot summary and transcript (read from
./test_data). During the demo you click the AI buttons (Build RCM, Run CDE/COE/DA,
Conclude) live — the rule-based engine returns the curated workpaper output instantly.

The CDE/COE result workbooks, the TIP (PDF) and the Security Access Matrix (Word) are
separate test files you open directly in Excel/PDF/Word to show evidence.
"""

import os

from db_models import ControlWorkpaper, Document, Project
from document_extractor import extract_text

TEST_DIR = os.path.join(os.path.dirname(__file__), "test_data")

PROJECT = {"name": "Database Access Management Audit — FY26", "reference": "DBAM-FY26",
           "created_by": "Ananya Aithal"}

# control_name -> list of (filename, doc_type, phase)
SEED = [
    ("Database Privileged Access Management", [
        ("Copilot_Summary_DB_Access_Mgmt_Walkthrough.docx", "COPILOT_SUMMARY", "WALKTHROUGH"),
        ("Transcript_DB_Access_Mgmt_Walkthrough.txt", "TRANSCRIPT", "WALKTHROUGH"),
    ]),
]


def _read(filename):
    path = os.path.join(TEST_DIR, filename)
    try:
        with open(path, "rb") as f:
            return extract_text(filename, f.read())
    except OSError:
        return f"[seed placeholder for {filename}]"


def seed_demo(db) -> int:
    project = Project(name=PROJECT["name"], reference=PROJECT["reference"],
                      status="Fieldwork", created_by=PROJECT["created_by"])
    db.add(project)
    db.flush()
    for control_name, docs in SEED:
        control = ControlWorkpaper(project_id=project.id, name=control_name,
                                   rcm=[], suggested_tests=[], phase_results={}, overall_conclusion="")
        db.add(control)
        db.flush()
        for filename, doc_type, phase in docs:
            db.add(Document(control_id=control.id, filename=filename, doc_type=doc_type,
                            phase=phase, extracted_text=_read(filename)))
    db.commit()
    return project.id


def demo_project_exists(db) -> bool:
    return db.query(Project).filter_by(reference=PROJECT["reference"]).first() is not None
