"""
UC-01 · Database models (SQLAlchemy)

Storage mirrors the original DB-backed UC-01: a Project holds ControlWorkpapers,
each of which carries its RCM, AI-suggested tests and per-phase results as JSON,
plus uploaded Documents (transcripts + supporting docs) with extracted text.

Default DB is SQLite (zero-setup for the demo). To use Postgres instead, set:
    UC01_DB_URL=postgresql+psycopg2://user:pass@host:5432/uc01
and add psycopg2-binary to requirements.
"""

import os
from datetime import datetime

from sqlalchemy import (
    JSON, Column, DateTime, ForeignKey, Integer, String, Text, create_engine,
)
from sqlalchemy.ext.mutable import MutableDict, MutableList
from sqlalchemy.orm import declarative_base, relationship, sessionmaker

DB_URL = os.environ.get("UC01_DB_URL", "sqlite:///uc01.db")

_connect_args = {"check_same_thread": False} if DB_URL.startswith("sqlite") else {}
engine = create_engine(DB_URL, connect_args=_connect_args, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False, future=True)
Base = declarative_base()


# ── The 17-column GIA RCM (dict keys used everywhere) ─────────────────────
RCM_FIELDS = [
    "process_ref", "process_title", "process_description",
    "risk_ref", "risk_title", "risk_description",
    "control_ref", "control_title", "control_description",
    "related_key_questions",
    "cde_required", "coe_required", "cde_or_coe_da_required",
    "cde_test_procedures", "coe_test_procedures", "da_test_procedure",
    "audit_team_member",
]

TESTING_PHASES = ["CDE", "COE", "DA", "EXCEPTIONS"]


def blank_rcm_row() -> dict:
    row = {f: "" for f in RCM_FIELDS}
    row["cde_required"] = "Yes"
    row["coe_required"] = "Yes"
    row["cde_or_coe_da_required"] = "No"
    return row


class Project(Base):
    __tablename__ = "project"

    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    reference = Column(String(128), default="")
    status = Column(String(64), default="Planning")
    created_by = Column(String(128), default="")
    created_at = Column(DateTime, default=datetime.utcnow)

    controls = relationship(
        "ControlWorkpaper", back_populates="project",
        cascade="all, delete-orphan", order_by="ControlWorkpaper.id",
    )


class ControlWorkpaper(Base):
    __tablename__ = "control_workpaper"

    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("project.id"), nullable=False)
    name = Column(String(255), nullable=False)
    current_phase = Column(String(32), default="WALKTHROUGH")

    # RCM: list of 17-field dicts
    rcm = Column(MutableList.as_mutable(JSON), default=list)
    # AI-suggested tests: list of {control_ref, cde_test_procedures, coe_test_procedures, da_test_procedure, accepted}
    suggested_tests = Column(MutableList.as_mutable(JSON), default=list)
    # Per-phase results: {"CDE": {"ai_result": "", "auditor_result": "", "edited": False}, ...}
    phase_results = Column(MutableDict.as_mutable(JSON), default=dict)

    overall_conclusion = Column(Text, default="")

    project = relationship("Project", back_populates="controls")
    documents = relationship(
        "Document", back_populates="control",
        cascade="all, delete-orphan", order_by="Document.id",
    )


class Document(Base):
    __tablename__ = "document"

    id = Column(Integer, primary_key=True)
    control_id = Column(Integer, ForeignKey("control_workpaper.id"), nullable=False)
    filename = Column(String(512), nullable=False)
    doc_type = Column(String(64), default="OTHER")
    phase = Column(String(32), default="WALKTHROUGH")
    extracted_text = Column(Text, default="")
    uploaded_at = Column(DateTime, default=datetime.utcnow)

    control = relationship("ControlWorkpaper", back_populates="documents")


def init_db():
    Base.metadata.create_all(engine)


def get_db():
    return SessionLocal()
