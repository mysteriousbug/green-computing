# UC-01 — Demo Runbook (Database Services Audit)

A tight script for the manager demo. Everything runs **offline, rule-based** — no
API key, no Power Automate, no DLP. Deterministic: identical every run.

## Before you start (1 min)
```bash
cd uc01-streamlit
pip install -r requirements.txt      # first time only
streamlit run app.py
```
- Sidebar shows **🔵 Demo mode — rule-based (no API key needed)**. Good.
- Open **🎬 Demo data → Load Database Access Management demo**. This creates the engagement
  *Database Access Management Audit — FY26* with three controls, transcripts and evidence
  already attached.

## The walkthrough (~5–6 min) — do the star control live
Pick **Database Privileged Access Management** in the sidebar.

1. **Documents tab** — point out the pre-loaded walkthrough transcript + TIP/scan
   supporting doc + CDE/COE/DA evidence. *"These are the walkthrough and RFI
   artefacts we'd normally collect."* Click **Build RCM from documents →**.
2. **RCM tab** — the 17-column GIA RCM appears (CO1.0, WHO-WHEN-WHAT-HOW-WHY control,
   key questions, CDE/COE/DA procedures). Expand the row; edit a field to show it's
   fully auditor-editable. *(Optional: click **Suggest test procedures →** to show
   the AI-suggested tests, then **Accept into RCM**.)*
3. **Testing Phases tab** — run each sub-tab live:
   - **CDE** → *Well Designed with minor gaps* (scan coverage Prod/DR only; MSSQL TIP overdue).
   - **COE** → *Operating with exceptions* (Q3 147 / Q4 163 deviations; **Oracle Oct-25 CPU 47 days**, Jan-26 CPU 35 days open).
   - **DA** → deviation trend +10.9%, patch ageing on legacy estate.
   - **EXCEPTIONS** → consolidated log (EX-01 patch SLA breach, EX-02 scan coverage, EX-03 MSSQL TIP).
   Edit any result to show auditor override.
4. **Conclusion tab** — **Generate conclusion →** → *Partially Effective*, residual risk Medium. Edit if you like.
5. **Export tab** — download **RCM (.xlsx)** and **Workpaper (.docx)**. Open the docx to show the formatted workpaper.

If time allows, switch to **Privileged Access Management** (CyberArk; SoD self-approval
3/18, late revocation, MongoDB vaulting gap, 7 credential-sharing sessions) or
**Backup and Restoration** (DB-ORAPROD-17, 2 Tier-1 databases untested) to show breadth.

## The close — how it goes live (30 sec)
Open the sidebar **🔑 Live analysis** panel. *"Today this runs on deterministic
rule-based logic so it works entirely inside the bank with no external calls. The
moment the AI wing issues an API key, I paste it here, pick the provider, and the
exact same buttons run real analysis on real transcripts — no Power Automate, no DLP
dependency."*

## Talking points
- **Human-in-the-loop**: every RCM row, test procedure, phase result and conclusion
  is auditor-reviewed and editable before it lands in the workpaper.
- **Time saved**: drafting the RCM + CDE/COE/DA narrative from a walkthrough drops
  from hours to minutes.
- **Governed by design**: demo mode makes no external calls; live mode uses a single
  approved API key rather than an open egress path.

## If something hiccups
- Nothing appears after a click → make sure a **control is selected** in the sidebar.
- Want a clean slate → delete `uc01.db` next to `app.py` and restart; re-seed from
  **🎬 Demo data**.
- Prefer to show the upload flow → the same files are in `test_data/` to drag in
  manually (filenames map to control + phase).
