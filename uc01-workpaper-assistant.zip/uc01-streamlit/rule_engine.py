"""
UC-01 · Rule-based demo engine (no LLM)

Deterministic engine used for the demo. It maps the control (by name, then by
document keywords) to the curated Database Services workpaper fixtures and returns
workpaper-accurate output every run — no API key, no network, no Power Automate.

Exposes the same method surface the app expects from the AI engine, so the app is
identical whether it runs in demo mode or live (API-key) mode.
"""

import fixtures


def _docs_text(transcripts, supporting_docs, phase_docs=None):
    parts = []
    for group in (transcripts or [], supporting_docs or [], phase_docs or []):
        for d in group:
            parts.append(d.get("filename", ""))
            parts.append((d.get("content") or "")[:2000])
    return " ".join(parts)


def _resolve(control_name, docs_text):
    key = fixtures.match_control_key(control_name, docs_text)
    return fixtures.CONTROLS.get(key) if key else None


class RuleBasedEngine:
    """Deterministic engine. `flow_url`/key args are accepted and ignored for
    interface parity with the live engine."""

    label = "Demo (rule-based)"

    def build_rcm(self, control_name, audit_name, transcripts, supporting_docs, flow_url=None):
        ctrl = _resolve(control_name, _docs_text(transcripts, supporting_docs))
        if ctrl:
            # return copies so the app can edit without touching the fixture
            return [dict(r) for r in ctrl["rcm"]]
        # graceful fallback: a single scaffold row keyed off the control name
        row = {f: "" for f in fixtures.CONTROLS["CONFIG_PATCH"]["rcm"][0].keys()}
        row["process_title"] = control_name or "Process"
        row["control_title"] = control_name or "Control"
        row["control_ref"] = "CO1.0"
        row["cde_required"] = row["coe_required"] = "Yes"
        row["cde_or_coe_da_required"] = "No"
        return [row]

    def suggest_test_procedures(self, control_name, rcm_rows, supporting_docs, flow_url=None):
        # Suggestions mirror the curated RCM test procedures, per control_ref.
        out = []
        for r in (rcm_rows or []):
            out.append({
                "control_ref": r.get("control_ref", ""),
                "cde_test_procedures": r.get("cde_test_procedures", ""),
                "coe_test_procedures": r.get("coe_test_procedures", ""),
                "da_test_procedure": r.get("da_test_procedure", ""),
                "accepted": False,
            })
        return out

    def analyze_phase(self, control_name, phase, rcm_rows, phase_docs, prior_results, flow_url=None):
        ctrl = _resolve(control_name, _docs_text(None, None, phase_docs))
        if ctrl:
            text = ctrl["phases"].get(phase, "")
            if text:
                return text
        return f"## {phase}\n\n_No curated {phase} content for this control in demo mode._"

    def conclude(self, control_name, rcm_rows, phase_results, flow_url=None):
        ctrl = _resolve(control_name, "")
        if ctrl:
            return ctrl["conclusion"]
        return "## Overall Conclusion\n\n_Demo mode: add an API key for live synthesis._"
