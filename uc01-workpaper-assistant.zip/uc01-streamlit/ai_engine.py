"""
UC-01 · AI engine (Power Automate + Copilot relay)

Replaces the original Groq/Llama calls. All prompt logic stays here in Python;
Power Automate is a thin relay that forwards systemPrompt + userPrompt to Copilot
/ AI Builder and returns text.

Relay contract (identical to the Quarkus PoC, so one flow serves both):
    POST { task, responseFormat, systemPrompt, userPrompt }
      -> { "output": "<text>" }   on success
      -> { "error":  "<msg>"  }   on failure

Configure the flow URL via the UC01_FLOW_URL env var, or pass flow_url explicitly
(the Streamlit sidebar lets you paste it at demo time).
"""

import json
import os
import re

import requests

RCM_FIELDS = [
    "process_ref", "process_title", "process_description",
    "risk_ref", "risk_title", "risk_description",
    "control_ref", "control_title", "control_description",
    "related_key_questions",
    "cde_required", "coe_required", "cde_or_coe_da_required",
    "cde_test_procedures", "coe_test_procedures", "da_test_procedure",
    "audit_team_member",
]

TRANSCRIPT_CAP = 6000   # chars per transcript sent to the model
DOC_CAP = 4000          # chars per supporting doc
TIMEOUT = int(os.environ.get("UC01_AI_TIMEOUT", "120"))


# ══════════════════════════════════════════════════════════════════════════
# Relay
# ══════════════════════════════════════════════════════════════════════════
def _resolve_flow_url(flow_url: str | None) -> str:
    url = (flow_url or os.environ.get("UC01_FLOW_URL", "")).strip()
    if not url:
        raise RuntimeError(
            "No Power Automate flow URL configured. Paste it in the sidebar or set "
            "the UC01_FLOW_URL environment variable. See power-automate/FLOW_SETUP.md."
        )
    return url


def _call_flow(task: str, response_format: str, system_prompt: str,
               user_prompt: str, flow_url: str | None = None) -> str:
    url = _resolve_flow_url(flow_url)
    payload = {
        "task": task,
        "responseFormat": response_format,
        "systemPrompt": system_prompt,
        "userPrompt": user_prompt,
    }
    try:
        resp = requests.post(url, json=payload, timeout=TIMEOUT)
    except requests.RequestException as e:
        raise RuntimeError(f"Failed to reach Power Automate flow: {e}") from e

    if resp.status_code // 100 != 2:
        raise RuntimeError(f"Power Automate returned HTTP {resp.status_code}: {resp.text[:500]}")

    try:
        data = resp.json()
    except ValueError:
        # Some flows return the raw string body; treat it as output.
        return resp.text

    if isinstance(data, dict):
        if data.get("error"):
            raise RuntimeError(f"Flow error: {data['error']}")
        if data.get("output") is not None:
            return data["output"]
    # Fallback: stringify whatever came back.
    return data if isinstance(data, str) else json.dumps(data)


# ══════════════════════════════════════════════════════════════════════════
# Prompts (ported from the original engine)
# ══════════════════════════════════════════════════════════════════════════
RCM_SYSTEM_PROMPT = """You are an expert internal auditor building a Risk Control Matrix (RCM)
following GIA methodology. Based on the walkthrough transcript(s) and supporting
documents (process docs, access matrices, technical implementation docs, risk
ratings, policies), build the RCM.

Respond ONLY with a JSON array (no prose, no markdown fences). Each object MUST
have exactly these fields:
[
  {
    "process_ref": "PR-001",
    "process_title": "Short process name",
    "process_description": "2-3 sentence description of the process",
    "risk_ref": "R-001",
    "risk_title": "Short risk title",
    "risk_description": "Risk statement covering cause and business impact (data breach, financial, reputational, regulatory, operational)",
    "control_ref": "CO1.0",
    "control_title": "Short control title",
    "control_description": "The [WHO] (WHO) [trigger/frequency] (WHEN) [performs action] (WHAT) [using tools/standards] (HOW/WHERE) to ensure [objective] (WHY).",
    "related_key_questions": "Q1. ...\\nQ2. ...\\nQ3. ...",
    "cde_required": "Yes",
    "coe_required": "Yes",
    "cde_or_coe_da_required": "No",
    "cde_test_procedures": "Process Walkthrough\\n1. ...\\nTest Of One\\n2. ...",
    "coe_test_procedures": "Based on GIA sampling methodology:\\n1. ...",
    "da_test_procedure": "",
    "audit_team_member": ""
  }
]

CRITICAL REQUIREMENTS:
1. Control descriptions MUST follow WHO-WHEN-WHAT-HOW-WHY.
2. CDE test procedures MUST include a Process Walkthrough AND a Test of One.
3. COE test procedures MUST reference GIA sampling methodology.
4. Risk descriptions MUST articulate specific business impact.
5. Key questions MUST be specific and testable, not generic.
6. Base everything on what was actually discussed — do NOT fabricate processes
   or systems not mentioned in the inputs.
7. Create separate rows for distinct risk-control pairs."""

SUGGEST_TESTS_SYSTEM_PROMPT = """You are an expert internal auditor suggesting detailed test procedures for an
existing RCM. For each control, propose CDE, COE and (if applicable) DA
procedures the auditor can review and override.

Respond ONLY with a JSON array (no markdown fences):
[
  {
    "control_ref": "CO1.0",
    "cde_test_procedures": "Process Walkthrough\\n1. ...\\nTest Of One\\n2. ...",
    "coe_test_procedures": "Based on GIA sampling methodology:\\n1. ...",
    "da_test_procedure": "..."
  }
]

Requirements:
- CDE = Process Walkthrough + Test of One.
- COE = GIA sampling methodology.
- Ground the steps in the supplied RCM and supporting documents.
- Steps must be specific and actionable, not generic."""

PHASE_SYSTEM_PROMPTS = {
    "CDE": """You are an internal auditor performing Control Design Effectiveness (CDE)
analysis. Using the RCM, the CDE test procedures and the uploaded phase evidence,
assess whether each control is DESIGNED effectively. For each control give:
observations, a design conclusion (Effective / Partially Effective / Ineffective)
and any design gaps. Respond in clear markdown.""",

    "COE": """You are an internal auditor performing Control Operating Effectiveness (COE)
analysis. Using the RCM, the COE test procedures (GIA sampling) and the uploaded
evidence/samples, assess whether each control OPERATED effectively over the
period. For each control give: sample results, an operating conclusion (Effective
/ Partially Effective / Ineffective) and exceptions found. Respond in clear
markdown.""",

    "DA": """You are an internal auditor performing Data Analytics (DA) testing. Using the
DA test procedure and the uploaded datasets/evidence, describe the analysis
performed, quantify results (population, anomalies, coverage) and give a DA
conclusion. Respond in clear markdown.""",

    "EXCEPTIONS": """You are an internal auditor consolidating exceptions. Review the CDE, COE and DA
results and produce a structured exceptions log: for each exception give a
reference, the control affected, the description, root cause, risk rating
(High/Medium/Low) and a recommended management action. Respond in clear markdown,
using a table where helpful.""",
}

CONCLUSION_SYSTEM_PROMPT = """You are the lead internal auditor writing the overall conclusion for this control
area. Synthesize the RCM, CDE, COE, DA and exceptions results into a concise
conclusion: overall control environment rating, key themes, material exceptions
and residual risk. Respond in clear markdown, 3-6 short paragraphs."""


# ══════════════════════════════════════════════════════════════════════════
# Operations
# ══════════════════════════════════════════════════════════════════════════
def build_rcm(control_name, audit_name, transcripts, supporting_docs, flow_url=None):
    """transcripts / supporting_docs: list of {'filename','doc_type','content'}."""
    parts = [f"Audit: {audit_name}", f"Control: {control_name}", ""]

    parts.append("=== WALKTHROUGH TRANSCRIPTS ===")
    for t in transcripts:
        parts.append(f"\n--- {t['filename']} ---")
        parts.append((t.get("content") or "")[:TRANSCRIPT_CAP])
    parts.append("")

    parts.append("=== SUPPORTING DOCUMENTS ===")
    for d in supporting_docs:
        parts.append(f"\n--- {d['filename']} (Type: {d.get('doc_type','OTHER')}) ---")
        parts.append((d.get("content") or "")[:DOC_CAP])

    raw = _call_flow("BUILD_RCM", "JSON_ARRAY", RCM_SYSTEM_PROMPT, "\n".join(parts), flow_url)
    rows = _parse_json_array(raw)
    return [_normalise_rcm_row(r) for r in rows]


def suggest_test_procedures(control_name, rcm_rows, supporting_docs, flow_url=None):
    parts = [f"Control: {control_name}", "", "Existing RCM (JSON):", json.dumps(rcm_rows, indent=2), ""]
    parts.append("Supporting documents:")
    for d in supporting_docs:
        parts.append(f"\n--- {d['filename']} (Type: {d.get('doc_type','OTHER')}) ---")
        parts.append((d.get("content") or "")[:DOC_CAP])

    raw = _call_flow("SUGGEST_TESTS", "JSON_ARRAY", SUGGEST_TESTS_SYSTEM_PROMPT, "\n".join(parts), flow_url)
    out = []
    for s in _parse_json_array(raw):
        out.append({
            "control_ref": s.get("control_ref", ""),
            "cde_test_procedures": s.get("cde_test_procedures", ""),
            "coe_test_procedures": s.get("coe_test_procedures", ""),
            "da_test_procedure": s.get("da_test_procedure", ""),
            "accepted": False,
        })
    return out


def analyze_phase(control_name, phase, rcm_rows, phase_docs, prior_results, flow_url=None):
    """phase in CDE/COE/DA/EXCEPTIONS. Returns markdown text."""
    parts = [f"Control: {control_name}", "", "RCM (JSON):", json.dumps(rcm_rows, indent=2), ""]

    if phase == "EXCEPTIONS":
        for ph, res in (prior_results or {}).items():
            text = (res or {}).get("auditor_result") or (res or {}).get("ai_result") or ""
            if text:
                parts.append(f"=== {ph} RESULT ===\n{text}\n")
    else:
        parts.append(f"=== {phase} PHASE EVIDENCE ===")
        for d in phase_docs:
            parts.append(f"\n--- {d['filename']} (Type: {d.get('doc_type','OTHER')}) ---")
            parts.append((d.get("content") or "")[:DOC_CAP])

    system = PHASE_SYSTEM_PROMPTS.get(phase, "You are an expert internal auditor. Respond in clear markdown.")
    return _call_flow("ANALYZE_PHASE", "TEXT", system, "\n".join(parts), flow_url)


def conclude(control_name, rcm_rows, phase_results, flow_url=None):
    parts = [f"Control: {control_name}", "", "RCM (JSON):", json.dumps(rcm_rows, indent=2), ""]
    for ph, res in (phase_results or {}).items():
        text = (res or {}).get("auditor_result") or (res or {}).get("ai_result") or ""
        if text:
            parts.append(f"=== {ph} RESULT ===\n{text}\n")
    return _call_flow("CONCLUDE", "TEXT", CONCLUSION_SYSTEM_PROMPT, "\n".join(parts), flow_url)


# ══════════════════════════════════════════════════════════════════════════
# Parsing helpers
# ══════════════════════════════════════════════════════════════════════════
def _strip_fences(raw: str) -> str:
    if not raw:
        return ""
    t = raw.strip()
    t = re.sub(r"```json", "```", t, flags=re.IGNORECASE).strip()
    if t.startswith("```"):
        t = t[3:]
        end = t.rfind("```")
        if end >= 0:
            t = t[:end]
    t = t.strip()
    # Slice to the outermost JSON array/object if prose surrounds it.
    starts = [i for i in (t.find("["), t.find("{")) if i >= 0]
    if starts:
        start = min(starts)
        close = "]" if t[start] == "[" else "}"
        last = t.rfind(close)
        if last > start:
            t = t[start:last + 1]
    return t.strip()


def _parse_json_array(raw: str):
    try:
        data = json.loads(_strip_fences(raw))
    except json.JSONDecodeError as e:
        raise RuntimeError(f"Could not parse model JSON: {e}\nRaw: {raw[:800]}") from e
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for v in data.values():
            if isinstance(v, list):
                return v
    raise RuntimeError("Expected a JSON array from the model.")


def _normalise_rcm_row(row: dict) -> dict:
    out = {f: (row.get(f) or "") for f in RCM_FIELDS}
    out["cde_required"] = row.get("cde_required") or "Yes"
    out["coe_required"] = row.get("coe_required") or "Yes"
    out["cde_or_coe_da_required"] = row.get("cde_or_coe_da_required") or "No"
    return out
