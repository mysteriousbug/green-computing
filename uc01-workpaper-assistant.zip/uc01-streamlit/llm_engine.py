"""
UC-01 · Live LLM engine (used when a real API key is supplied)

When the bank's AI wing issues an API key, the app switches from the rule-based
demo engine to this one — no Power Automate. Supports:
  - Anthropic Messages API
  - Any OpenAI-compatible chat/completions endpoint (incl. internal gateways),
    via a configurable base URL.

Prompts and JSON parsing are reused from ai_engine, so behaviour matches the
original design.
"""

import json

import requests

import ai_engine as prompts  # reuse RCM_SYSTEM_PROMPT etc. + parsing helpers

TIMEOUT = 120


class LiveLLMEngine:
    label = "Live (API key)"

    def __init__(self, api_key, provider="anthropic", base_url="", model=""):
        self.api_key = api_key
        self.provider = (provider or "anthropic").lower()
        self.base_url = base_url.rstrip("/") if base_url else ""
        self.model = model or self._default_model()

    def _default_model(self):
        return "claude-sonnet-4-6" if self.provider == "anthropic" else "gpt-4o"

    # ── transport ─────────────────────────────────────────────────────────
    def _chat(self, system_prompt, user_prompt):
        if not self.api_key:
            raise RuntimeError("No API key set. Enter one in the sidebar to run live analysis.")
        if self.provider == "anthropic":
            return self._anthropic(system_prompt, user_prompt)
        return self._openai_compatible(system_prompt, user_prompt)

    def _anthropic(self, system_prompt, user_prompt):
        url = (self.base_url or "https://api.anthropic.com") + "/v1/messages"
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        body = {
            "model": self.model,
            "max_tokens": 4096,
            "temperature": 0.2,
            "system": system_prompt,
            "messages": [{"role": "user", "content": user_prompt}],
        }
        r = requests.post(url, headers=headers, json=body, timeout=TIMEOUT)
        if r.status_code // 100 != 2:
            raise RuntimeError(f"Anthropic API HTTP {r.status_code}: {r.text[:400]}")
        data = r.json()
        return "".join(block.get("text", "") for block in data.get("content", []))

    def _openai_compatible(self, system_prompt, user_prompt):
        base = self.base_url or "https://api.openai.com"
        url = base + "/v1/chat/completions"
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        body = {
            "model": self.model,
            "temperature": 0.2,
            "max_tokens": 4096,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        }
        r = requests.post(url, headers=headers, json=body, timeout=TIMEOUT)
        if r.status_code // 100 != 2:
            raise RuntimeError(f"LLM API HTTP {r.status_code}: {r.text[:400]}")
        data = r.json()
        return data["choices"][0]["message"]["content"]

    # ── operations (build prompts via ai_engine, then parse) ──────────────
    def build_rcm(self, control_name, audit_name, transcripts, supporting_docs, flow_url=None):
        parts = [f"Audit: {audit_name}", f"Control: {control_name}", "", "=== WALKTHROUGH TRANSCRIPTS ==="]
        for t in transcripts or []:
            parts.append(f"\n--- {t['filename']} ---")
            parts.append((t.get("content") or "")[:prompts.TRANSCRIPT_CAP])
        parts.append("\n=== SUPPORTING DOCUMENTS ===")
        for d in supporting_docs or []:
            parts.append(f"\n--- {d['filename']} (Type: {d.get('doc_type','OTHER')}) ---")
            parts.append((d.get("content") or "")[:prompts.DOC_CAP])
        raw = self._chat(prompts.RCM_SYSTEM_PROMPT, "\n".join(parts))
        return [prompts._normalise_rcm_row(r) for r in prompts._parse_json_array(raw)]

    def suggest_test_procedures(self, control_name, rcm_rows, supporting_docs, flow_url=None):
        parts = [f"Control: {control_name}", "", "Existing RCM (JSON):", json.dumps(rcm_rows, indent=2),
                 "", "Supporting documents:"]
        for d in supporting_docs or []:
            parts.append(f"\n--- {d['filename']} (Type: {d.get('doc_type','OTHER')}) ---")
            parts.append((d.get("content") or "")[:prompts.DOC_CAP])
        raw = self._chat(prompts.SUGGEST_TESTS_SYSTEM_PROMPT, "\n".join(parts))
        out = []
        for s in prompts._parse_json_array(raw):
            out.append({
                "control_ref": s.get("control_ref", ""),
                "cde_test_procedures": s.get("cde_test_procedures", ""),
                "coe_test_procedures": s.get("coe_test_procedures", ""),
                "da_test_procedure": s.get("da_test_procedure", ""),
                "accepted": False,
            })
        return out

    def analyze_phase(self, control_name, phase, rcm_rows, phase_docs, prior_results, flow_url=None):
        parts = [f"Control: {control_name}", "", "RCM (JSON):", json.dumps(rcm_rows, indent=2), ""]
        if phase == "EXCEPTIONS":
            for ph, res in (prior_results or {}).items():
                txt = (res or {}).get("auditor_result") or (res or {}).get("ai_result") or ""
                if txt:
                    parts.append(f"=== {ph} RESULT ===\n{txt}\n")
        else:
            parts.append(f"=== {phase} PHASE EVIDENCE ===")
            for d in phase_docs or []:
                parts.append(f"\n--- {d['filename']} ---")
                parts.append((d.get("content") or "")[:prompts.DOC_CAP])
        system = prompts.PHASE_SYSTEM_PROMPTS.get(phase, "You are an expert internal auditor. Respond in markdown.")
        return self._chat(system, "\n".join(parts))

    def conclude(self, control_name, rcm_rows, phase_results, flow_url=None):
        parts = [f"Control: {control_name}", "", "RCM (JSON):", json.dumps(rcm_rows, indent=2), ""]
        for ph, res in (phase_results or {}).items():
            txt = (res or {}).get("auditor_result") or (res or {}).get("ai_result") or ""
            if txt:
                parts.append(f"=== {ph} RESULT ===\n{txt}\n")
        return self._chat(prompts.CONCLUSION_SYSTEM_PROMPT, "\n".join(parts))
