"""
UC-01 · Exporters

Build the two deliverables from a ControlWorkpaper:
  - RCM as .xlsx (17 columns, one row per risk/control pair)
  - Workpaper as .docx (RCM table + per-phase results + conclusion)

Both return raw bytes for Streamlit's download_button.
"""

import io

from docx import Document as DocxDocument
from docx.shared import Pt
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill

RCM_HEADERS = [
    ("process_ref", "Process Ref"), ("process_title", "Process Title"),
    ("process_description", "Process Description"),
    ("risk_ref", "Risk Ref"), ("risk_title", "Risk Title"),
    ("risk_description", "Risk Description"),
    ("control_ref", "Control Ref"), ("control_title", "Control Title"),
    ("control_description", "Control Description"),
    ("related_key_questions", "Related Key Questions"),
    ("cde_required", "CDE Required"), ("coe_required", "COE Required"),
    ("cde_or_coe_da_required", "CDE or COE DA Required"),
    ("cde_test_procedures", "CDE Test Procedures"),
    ("coe_test_procedures", "COE Test Procedures"),
    ("da_test_procedure", "DA Test Procedure"),
    ("audit_team_member", "Audit Team Member"),
]


def export_rcm_xlsx(control) -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.title = "RCM"

    header_fill = PatternFill("solid", fgColor="0A6B62")
    header_font = Font(bold=True, color="FFFFFF")
    wrap = Alignment(wrap_text=True, vertical="top")

    for col, (_, label) in enumerate(RCM_HEADERS, start=1):
        cell = ws.cell(row=1, column=col, value=label)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = wrap
        ws.column_dimensions[cell.column_letter].width = 24

    for r, row in enumerate(control.rcm or [], start=2):
        for col, (key, _) in enumerate(RCM_HEADERS, start=1):
            cell = ws.cell(row=r, column=col, value=row.get(key, ""))
            cell.alignment = wrap

    ws.freeze_panes = "A2"

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def export_workpaper_docx(control, project_name="") -> bytes:
    doc = DocxDocument()

    title = doc.add_heading(f"Audit Workpaper: {control.name}", level=0)
    doc.add_paragraph(f"Engagement: {project_name}")
    doc.add_paragraph(f"Control area: {control.name}")

    doc.add_heading("Risk Control Matrix", level=1)
    _rcm_table(doc, control)

    for phase, res in (control.phase_results or {}).items():
        text = (res or {}).get("auditor_result") or (res or {}).get("ai_result") or ""
        if not text:
            continue
        doc.add_heading(f"{phase} Results", level=1)
        for line in text.splitlines():
            doc.add_paragraph(line)

    if control.overall_conclusion:
        doc.add_heading("Overall Conclusion", level=1)
        for line in control.overall_conclusion.splitlines():
            doc.add_paragraph(line)

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def _rcm_table(doc, control):
    rows = control.rcm or []
    table = doc.add_table(rows=1, cols=len(RCM_HEADERS))
    table.style = "Light Grid Accent 1"
    hdr = table.rows[0].cells
    for i, (_, label) in enumerate(RCM_HEADERS):
        run = hdr[i].paragraphs[0].add_run(label)
        run.bold = True
        run.font.size = Pt(8)
    for row in rows:
        cells = table.add_row().cells
        for i, (key, _) in enumerate(RCM_HEADERS):
            run = cells[i].paragraphs[0].add_run(str(row.get(key, "")))
            run.font.size = Pt(8)
