"""
UC-01 · Engine factory

Returns the deterministic demo engine by default, or the live LLM engine when an
API key is supplied. Both expose the same methods, so the app doesn't care which
one it's using.
"""

from rule_engine import RuleBasedEngine


def get_engine(api_key="", provider="anthropic", base_url="", model=""):
    if api_key and api_key.strip():
        # Imported lazily so demo mode has zero dependency on the live path.
        from llm_engine import LiveLLMEngine
        return LiveLLMEngine(api_key.strip(), provider, base_url, model)
    return RuleBasedEngine()
